import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import CurrentWeather from "./pages/CurrentWeather";
import HistoricalWeather from "./pages/HistoricalWeather";

function App() {
  return (
    <Router>
      <nav>
        <Link to="/">Home</Link> | <Link to="/history">History</Link>
      </nav>

      <Routes>
        <Route path="/" element={<CurrentWeather />} />
        <Route path="/history" element={<HistoricalWeather />} />
      </Routes>
    </Router>
  );
}

export default App;